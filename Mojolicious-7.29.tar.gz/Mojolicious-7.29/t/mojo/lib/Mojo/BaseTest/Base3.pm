package Mojo::BaseTest::Base3;
use Mojo::BaseTest::Base1 -base;

has 'test';

1;
